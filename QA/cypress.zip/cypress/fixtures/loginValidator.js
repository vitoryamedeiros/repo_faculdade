export function validarLogin(email, senha) {
  const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!email) {
    return { status: "erro", mensagem: "Preencha o campo de email." };
  }

   if (!regexEmail.test(email)) {
    return { status: "erro", mensagem: "Email inválido." };
  }

  if (!senha) {
    return { status: "erro", mensagem: "Preencha o campo de senha." };
  }

  if (email === "teste@email.com" && senha === "Senha@123") {
    return { status: "sucesso", mensagem: "Login bem-sucedido!" };
  }

  return { status: "erro", mensagem: "Email ou senha incorretos." };
}
