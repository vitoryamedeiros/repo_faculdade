import { validarLogin } from './loginValidator.js';

document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const email = document.getElementById("email").value.trim();
  const senha = document.getElementById("senha").value.trim();
  const erro = document.getElementById("mensagemErro");

  const resultado = validarLogin(email, senha);

  erro.style.color = resultado.status === "sucesso" ? "green" : "red";
  erro.textContent = resultado.mensagem;
});
