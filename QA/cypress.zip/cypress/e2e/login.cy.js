const { validarLogin } = require('../fixtures/loginValidator');

describe('Testes unitários de login', () => {
      it('deve retornar erro para campo de email vazio', () => {
        cy.then(() => {
          const resultado = validarLogin("", "");
          expect(resultado).to.deep.equal({
            status: "erro",
            mensagem: "Preencha o campo de email."
          });
        });
      });

      it('retorna erro para email invalido', () => {
        cy.then(() => {
          const resultado = validarLogin("stringaleatoria", "");
          expect(resultado).to.deep.equal({ status: "erro", mensagem: "Email inválido." });
        });
      });

      it('retorna erro para campo de senha vazio', () => {
        cy.then(() => {
          const resultado = validarLogin("teste@email.com", "");
          expect(resultado).to.deep.equal({ status: "erro", mensagem: "Preencha o campo de senha." });
        });
      });

      it('retorna erro de credenciais invalidas', () => {
        cy.then(() => {
          const resultado = validarLogin("teste2@email.com", "senha errada");
          expect(resultado).to.deep.equal({
            status: "erro",
            mensagem: "Email ou senha incorretos."
          });
        });
      });

      it('Login bem sucedido', () => {
        cy.then(() => {
          const resultado = validarLogin("teste@email.com", "Senha@123");
          expect(resultado).to.deep.equal({ status: "sucesso", mensagem: "Login bem-sucedido!" });
        });
    });
  });
